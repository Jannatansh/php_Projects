// script.js - Complete functionality for PRAGATI PORTAL with Authentication

// Authentication and Role Management
document.addEventListener('DOMContentLoaded', function() {
    initializeCharts();
    initializeSearch();
    initializeModals();
    checkAuthentication();
});

// Check if user is authenticated
function checkAuthentication() {
    const currentUser = sessionStorage.getItem('currentUser');
    const userRole = sessionStorage.getItem('userRole');
    
    // If on a protected page and not logged in, redirect to login
    const currentPage = window.location.pathname;
    if (!currentUser && !currentPage.includes('index.html') && currentPage !== '/') {
        window.location.href = 'index.html';
        return;
    }
    
    // Update UI with user info
    updateUserInterface(currentUser, userRole);
}

function updateUserInterface(username, role) {
    // Update user profile elements
    const userProfileElements = document.querySelectorAll('.user-profile span');
    userProfileElements.forEach(element => {
        if (username && !element.querySelector('img')) {
            element.textContent = username;
        }
    });
}

// Login functionality
function handleLogin(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role') ? document.getElementById('role').value : 'student';

    if (!role) {
        alert("Please select your role!");
        return;
    }

    if (username && password) {
        // Store user info in sessionStorage
        sessionStorage.setItem('currentUser', username);
        sessionStorage.setItem('userRole', role);
        
        // Redirect based on role
        switch(role) {
            case 'student':
                window.location.href = "student-domain.html";
                break;
            case 'teacher':
            case 'admin':
                window.location.href = "home.html";
                break;
            default:
                window.location.href = "home.html";
        }
    } else {
        alert("Please enter valid credentials!");
    }
}

// Logout function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        sessionStorage.removeItem('currentUser');
        sessionStorage.removeItem('userRole');
        window.location.href = 'index.html';
    }
}

// Chart initialization
function initializeCharts() {
    const ctx = document.getElementById('attendanceChart');
    if (ctx) {
        const attendanceChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
                datasets: [{
                    label: 'Attendance %',
                    data: [85, 88, 82, 90, 87, 80],
                    borderColor: '#7CA982',
                    backgroundColor: 'rgba(124, 169, 130, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                }
            }
        });
    }
}

// Search functionality
function initializeSearch() {
    const searchInput = document.getElementById('teacherSearch');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.data-table tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
}

// Modal functionality
function initializeModals() {
    // Add Teacher Modal
    const addTeacherModal = document.getElementById('addTeacherModal');
    const addTeacherForm = document.getElementById('addTeacherForm');
    
    if (addTeacherForm) {
        addTeacherForm.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('Teacher added successfully!');
            closeAddTeacherModal();
        });
    }
}

// Modal functions
function openAddTeacherModal() {
    document.getElementById('addTeacherModal').style.display = 'block';
}

function closeAddTeacherModal() {
    document.getElementById('addTeacherModal').style.display = 'none';
}

function openAnnouncementModal() {
    alert('New announcement modal would open here!');
}

// Timetable functions
function generateTimetable() {
    alert('AI Timetable generation started! This would connect to backend in real implementation.');
    setTimeout(() => {
        alert('Timetable generated successfully!');
    }, 2000);
}

// Attendance functions
function markAttendance() {
    alert('Attendance marking interface would open here!');
}

// Teacher management functions
function editTeacher(id) {
    alert(`Editing teacher with ID: ${id}`);
}

function deleteTeacher(id) {
    if (confirm('Are you sure you want to delete this teacher?')) {
        alert(`Teacher with ID: ${id} deleted successfully!`);
    }
}

// Student functions
function startAssignment(subject) {
    alert(`Starting ${subject} assignment...`);
}

function downloadMaterial(subject) {
    alert(`Downloading ${subject} material...`);
}

function startQuiz(subject) {
    alert(`Starting ${subject} quiz...`);
}

function downloadReport(type) {
    alert(`Downloading ${type} report...`);
}

function printResults() {
    window.print();
}

function openStudyMaterials() {
    alert('Opening study materials...');
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modals = document.getElementsByClassName('modal');
    for (let modal of modals) {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }
}

// Add event listener to login form if it exists
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', handleLogin);
}