<script>
  document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const user = document.getElementById("username").value;
    const pass = document.getElementById("password").value;
    const role = document.getElementById("select").value;

    // Simple validation
    if (!role) {
      alert("Please select your role!");
      return;
    }

    if (user && pass) {
      // Redirect based on role
      switch(role) {
        case 'student':
          window.location.href = "student-dashboard.html";
          break;
        case 'teacher':
          window.location.href = "teachers.html"; // Your teacher dashboard
          break;
        case 'hod':
          window.location.href = "index.html"; // Your admin/HOD dashboard
          break;
        default:
          window.location.href = "home.html";
      }
    } else {
      alert("Please enter valid credentials!");
    }
  });
</script>